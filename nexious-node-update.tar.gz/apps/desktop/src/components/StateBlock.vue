<script setup lang="ts">
import { AlertTriangle, Inbox, LoaderCircle } from 'lucide-vue-next'
defineProps<{ loading?: boolean; error?: string; empty?: boolean }>()
</script>
<template><div v-if="loading||error||empty" class="state-block"><LoaderCircle v-if="loading" class="spin"/><AlertTriangle v-else-if="error"/><Inbox v-else/><b>{{loading?'正在同步数据':error||'暂无数据'}}</b><p v-if="error">请确认本地 API 服务已启动后重试。</p><slot/></div></template>
