export interface Tunnel { id:string; name:string; protocol:'tcp'|'udp'|'http'|'https'; local_host:string; local_port:number; remote_port:number; node_id:string; node_name:string; node_city:string; latency:number; status:'running'|'stopped'; domain:string|null; created_at:string }
export interface NodeInfo { id:string; name:string; region:string; city:string; latency:number; load:number; status:'online'|'maintenance'; host:string }
export type NodeInput = Omit<NodeInfo, 'id'>
export interface TrafficPoint { timestamp:string; inbound:number; outbound:number }
export interface Dashboard { tunnels:Tunnel[]; totals:{ inbound:number; outbound:number }; series:TrafficPoint[]; onlineNodes:number; activeTunnels:number }
export interface AccessLog { id:number; tunnel_id:string; timestamp:string; client_ip:string; method:string; path:string; status:number; duration:number; bytes:number }
export interface Preferences { autoStart:boolean; minimizeToTray:boolean; notifications:boolean; updateChannel:'stable'|'beta' }
export interface TunnelInput { name:string; protocol:Tunnel['protocol']; localHost:string; localPort:number; remotePort:number; nodeId:string; domain:string|null }
