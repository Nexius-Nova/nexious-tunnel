import { createApp } from 'vue'
import { VueQueryPlugin, QueryClient } from '@tanstack/vue-query'
import { createRouter, createWebHashHistory } from 'vue-router'
import App from './App.vue'
import './styles.css'
const router = createRouter({ history:createWebHashHistory(), routes:[
  {path:'/',component:()=>import('./views/DashboardView.vue')},{path:'/tunnels',component:()=>import('./views/TunnelsView.vue')},{path:'/nodes',component:()=>import('./views/NodesView.vue')},{path:'/logs',component:()=>import('./views/LogsView.vue')},{path:'/settings',component:()=>import('./views/SettingsView.vue')}
]})
const queryClient = new QueryClient({defaultOptions:{queries:{staleTime:15000,retry:1,refetchOnWindowFocus:false}}})
createApp(App).use(router).use(VueQueryPlugin,{queryClient}).mount('#app')
