<script setup lang="ts">
import { computed, h, ref } from 'vue'
import { useQuery } from '@tanstack/vue-query'
import { NDataTable, NSelect, NTag, type DataTableColumns } from 'naive-ui'
import { api } from '../api/client'
import type { AccessLog } from '../types'
import PageHeader from '../components/PageHeader.vue'
import StateBlock from '../components/StateBlock.vue'
const selected = ref('all')
const tunnels = useQuery({ queryKey: ['tunnels'], queryFn: api.tunnels })
const logs = useQuery({ queryKey: ['logs', selected], queryFn: () => api.logs(selected.value === 'all' ? undefined : selected.value) })
const options = computed(() => [{ label: '全部隧道', value: 'all' }, ...(tunnels.data.value || []).map((tunnel) => ({ label: tunnel.name, value: tunnel.id }))])
const columns: DataTableColumns<AccessLog> = [
  { title: '时间', key: 'timestamp', render: (row) => new Date(row.timestamp).toLocaleString('zh-CN') },
  { title: '来源 IP', key: 'client_ip' }, { title: '请求', key: 'path', render: (row) => `${row.method}  ${row.path}` },
  { title: '状态码', key: 'status', render: (row) => h(NTag, { size: 'small', type: row.status < 400 ? 'success' : 'error', bordered: false }, { default: () => row.status }) },
  { title: '耗时', key: 'duration', render: (row) => `${row.duration} ms` }, { title: '流量', key: 'bytes', render: (row) => `${(row.bytes / 1024).toFixed(1)} KB` },
]
</script>
<template><div class="view"><PageHeader eyebrow="ACCESS OBSERVATORY" title="访问日志" description="追踪每次穿透请求的来源、状态与响应耗时。"><n-select v-model:value="selected" :options="options" style="width:200px"/></PageHeader><StateBlock v-if="logs.isLoading.value||logs.error.value||!logs.data.value?.length" :loading="logs.isLoading.value" :error="logs.error.value?.message" :empty="!logs.isLoading.value&&!logs.error.value&&!logs.data.value?.length"/><div v-else class="table-panel"><n-data-table :data="logs.data.value" :columns="columns" :bordered="false"/></div></div></template>
