<script setup lang="ts">
import { computed, h, ref } from 'vue'
import { NConfigProvider, NDialogProvider, NIcon, NLayout, NLayoutContent, NLayoutSider, NMenu, NMessageProvider, NNotificationProvider, darkTheme, type MenuOption } from 'naive-ui'
import { Activity, BookOpenText, Cable, ChevronLeft, CircleGauge, MapPin, Moon, Settings, Sun, Zap } from 'lucide-vue-next'
import { useRoute, useRouter } from 'vue-router'
const collapsed=ref(false), route=useRoute(), router=useRouter(), isDark=ref(localStorage.getItem('nexious-theme') !== 'light')
function toggleTheme() { isDark.value = !isDark.value; localStorage.setItem('nexious-theme', isDark.value ? 'dark' : 'light') }
const icon=(component:unknown)=>()=>h(NIcon,null,{default:()=>h(component as never)})
const menu:MenuOption[]=[
  {label:'运行总览',key:'/',icon:icon(CircleGauge)},{label:'隧道管理',key:'/tunnels',icon:icon(Cable)},
  {label:'边缘节点',key:'/nodes',icon:icon(MapPin)},{label:'访问日志',key:'/logs',icon:icon(BookOpenText)},
  {type:'divider',key:'d'},{label:'偏好设置',key:'/settings',icon:icon(Settings)}
]
const mobileMenu = [
  { label: '总览', path: '/', icon: CircleGauge }, { label: '隧道', path: '/tunnels', icon: Cable },
  { label: '节点', path: '/nodes', icon: MapPin }, { label: '日志', path: '/logs', icon: BookOpenText },
  { label: '设置', path: '/settings', icon: Settings },
]
const active=computed(()=>route.path)
</script>
<template>
 <n-config-provider :theme="isDark ? darkTheme : null" :theme-overrides="{ common:{ primaryColor:'#239b61',primaryColorHover:'#2ebd78',primaryColorPressed:'#187a4b',borderRadius:'6px',fontFamily:'\'IBM Plex Sans\',\'Microsoft YaHei\',sans-serif' } }">
  <n-dialog-provider><n-notification-provider><n-message-provider>
   <n-layout has-sider class="shell" :class="{ 'theme-light': !isDark }">
    <n-layout-sider bordered collapse-mode="width" :collapsed-width="72" :width="232" :collapsed="collapsed" class="sidebar">
      <div class="brand" :class="{compact:collapsed}"><div class="brand-mark"><Zap :size="20" fill="currentColor"/></div><div v-if="!collapsed"><strong>NEXIOUS</strong><span>TUNNEL</span></div><button class="theme-button" :aria-label="isDark?'切换到白色主题':'切换到黑色主题'" :title="isDark?'白色主题':'黑色主题'" @click="toggleTheme"><Sun v-if="isDark" :size="16"/><Moon v-else :size="16"/></button></div>
      <n-menu :collapsed="collapsed" :collapsed-width="72" :collapsed-icon-size="21" :value="active" :options="menu" @update:value="(v: string)=>router.push(v)"/>
      <button class="collapse-button" :aria-label="collapsed?'展开侧栏':'收起侧栏'" @click="collapsed=!collapsed"><ChevronLeft :size="17" :class="{flip:collapsed}"/><span v-if="!collapsed">收起侧栏</span></button>
      <div v-if="!collapsed" class="daemon"><i></i><div><b>本地服务在线</b><span>127.0.0.1:8787</span></div><Activity :size="16"/></div>
    </n-layout-sider>
    <n-layout><n-layout-content class="content"><router-view/></n-layout-content></n-layout>
    <nav class="mobile-nav"><button v-for="item in mobileMenu" :key="item.path" :class="{active:active===item.path}" @click="router.push(item.path)"><component :is="item.icon"/><span>{{item.label}}</span></button></nav>
   </n-layout>
  </n-message-provider></n-notification-provider></n-dialog-provider>
 </n-config-provider>
</template>
