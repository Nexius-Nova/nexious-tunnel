# Nexious Tunnel 个人使用

## 1. 在阿里云服务器上启动中转服务

将项目部署到服务器后：

```bash
pnpm install
PORT=8787 pnpm --filter @nexious/server start
```

建议用 Nginx 将 `tunnel.example.com` 的 WebSocket 和 HTTP 转发到 `127.0.0.1:8787`，并放行 80/443。

## 2. 创建隧道并生成 token

在桌面端创建隧道，例如本地地址 `127.0.0.1`、端口 `8080`。调用：

```bash
curl -X POST http://127.0.0.1:8787/api/tunnels/TUNNEL_ID/token
```

## 3. 在本地电脑运行 agent

```bash
pnpm --filter @nexious/agent start -- \
  --relay wss://tunnel.example.com/relay \
  --tunnel TUNNEL_ID \
  --token TOKEN \
  --target http://127.0.0.1:8080
```

公网访问地址为：`https://tunnel.example.com/public/TUNNEL_ID/`。

当前实现是 HTTP/HTTPS 反向代理，适合个人开发站点、Webhook、内网面板等；TCP/UDP 端口转发需要后续增加二进制流模式。
