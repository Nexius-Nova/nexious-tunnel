const baseUrl = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8787/api';
export class ApiError extends Error {
    status;
    constructor(message, status) {
        super(message);
        this.status = status;
    }
}
async function request(path, options = {}) {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 8000);
    try {
        const response = await fetch(`${baseUrl}${path}`, { ...options, signal: controller.signal, headers: { 'Content-Type': 'application/json', ...options.headers } });
        if (!response.ok) {
            const body = await response.json().catch(() => null);
            throw new ApiError(body?.message || `请求失败 (${response.status})`, response.status);
        }
        return response.status === 204 ? undefined : response.json();
    }
    catch (error) {
        if (error instanceof ApiError)
            throw error;
        throw new ApiError(error instanceof DOMException && error.name === 'AbortError' ? '请求超时，请检查服务状态' : '无法连接本地服务', 0);
    }
    finally {
        window.clearTimeout(timer);
    }
}
export const api = {
    dashboard: () => request('/dashboard'), tunnels: () => request('/tunnels'), nodes: () => request('/nodes'),
    createTunnel: (value) => request('/tunnels', { method: 'POST', body: JSON.stringify(value) }),
    updateTunnel: (id, value) => request(`/tunnels/${id}`, { method: 'PUT', body: JSON.stringify(value) }),
    setTunnelStatus: (id, status) => request(`/tunnels/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }),
    deleteTunnel: (id) => request(`/tunnels/${id}`, { method: 'DELETE' }),
    logs: (tunnelId) => request(`/logs${tunnelId ? `?tunnelId=${encodeURIComponent(tunnelId)}` : ''}`),
    settings: () => request('/settings'), saveSettings: (value) => request('/settings', { method: 'PUT', body: JSON.stringify(value) })
};
