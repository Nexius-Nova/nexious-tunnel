import type { AccessLog, Dashboard, NodeInfo, Preferences, Tunnel, TunnelInput } from '../types'
const baseUrl = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8787/api'
const apiToken = import.meta.env.VITE_API_TOKEN || ''
export class ApiError extends Error { constructor(message:string, public status:number) { super(message) } }
async function request<T>(path:string, options:RequestInit = {}):Promise<T> {
  const controller = new AbortController()
  const timer = window.setTimeout(() => controller.abort(), 8000)
  try {
    const response = await fetch(`${baseUrl}${path}`, { ...options, signal:controller.signal, headers:{ 'Content-Type':'application/json', ...(apiToken ? { Authorization:`Bearer ${apiToken}` } : {}), ...options.headers } })
    if (!response.ok) { const body = await response.json().catch(() => null); throw new ApiError(body?.message || `请求失败 (${response.status})`, response.status) }
    return response.status === 204 ? undefined as T : response.json()
  } catch (error) {
    if (error instanceof ApiError) throw error
    throw new ApiError(error instanceof DOMException && error.name === 'AbortError' ? '请求超时，请检查服务状态' : '无法连接本地服务', 0)
  } finally { window.clearTimeout(timer) }
}
export const api = {
  dashboard: () => request<Dashboard>('/dashboard'), tunnels:() => request<Tunnel[]>('/tunnels'), nodes:() => request<NodeInfo[]>('/nodes'),
  createTunnel:(value:TunnelInput) => request<Tunnel>('/tunnels',{method:'POST',body:JSON.stringify(value)}),
  updateTunnel:(id:string,value:TunnelInput) => request<Tunnel>(`/tunnels/${id}`,{method:'PUT',body:JSON.stringify(value)}),
  setTunnelStatus:(id:string,status:Tunnel['status']) => request(`/tunnels/${id}/status`,{method:'PATCH',body:JSON.stringify({status})}),
  deleteTunnel:(id:string) => request<void>(`/tunnels/${id}`,{method:'DELETE'}),
  issueToken:(id:string) => request<{token:string; tunnelId:string; relay:string}>(`/tunnels/${id}/token`,{method:'POST'}),
  agentCommand:(id:string) => request<{command:string}>(`/tunnels/${id}/agent-command`),
  logs:(tunnelId?:string) => request<AccessLog[]>(`/logs${tunnelId ? `?tunnelId=${encodeURIComponent(tunnelId)}` : ''}`),
  settings:() => request<Preferences>('/settings'), saveSettings:(value:Preferences) => request<Preferences>('/settings',{method:'PUT',body:JSON.stringify(value)})
}
