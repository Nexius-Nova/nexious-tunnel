import { computed, reactive, watch } from 'vue';
import { NButton, NDrawer, NDrawerContent, NForm, NFormItem, NInput, NInputNumber, NSelect, NSpace } from 'naive-ui';
import { ref } from 'vue';
const props = defineProps(), emit = defineEmits();
const formRef = ref(null), form = reactive({ name: '', protocol: 'https', localHost: '127.0.0.1', localPort: 3000, remotePort: 443, nodeId: '', domain: null });
watch(() => [props.show, props.tunnel, props.nodes], () => { if (!props.show)
    return; Object.assign(form, props.tunnel ? { name: props.tunnel.name, protocol: props.tunnel.protocol, localHost: props.tunnel.local_host, localPort: props.tunnel.local_port, remotePort: props.tunnel.remote_port, nodeId: props.tunnel.node_id, domain: props.tunnel.domain } : { name: '', protocol: 'https', localHost: '127.0.0.1', localPort: 3000, remotePort: 443, nodeId: props.nodes.find(n => n.status === 'online')?.id || '', domain: null }); }, { immediate: true });
const rules = { name: { required: true, message: '请输入至少 2 个字符的名称', min: 2, trigger: 'blur' }, localHost: { required: true, message: '请输入本地地址', trigger: 'blur' }, nodeId: { required: true, message: '请选择节点', trigger: 'change' } };
const nodeOptions = computed(() => props.nodes.map(n => ({ label: `${n.name} · ${n.latency}ms${n.status !== 'online' ? '（维护中）' : ''}`, value: n.id, disabled: n.status !== 'online' })));
async function submit() { await formRef.value?.validate(); emit('submit', { ...form, domain: ['http', 'https'].includes(form.protocol) ? form.domain : null }); }
debugger; /* PartiallyEnd: #3632/scriptSetup.vue */
const __VLS_ctx = {};
let __VLS_components;
let __VLS_directives;
const __VLS_0 = {}.NDrawer;
/** @type {[typeof __VLS_components.NDrawer, typeof __VLS_components.nDrawer, typeof __VLS_components.NDrawer, typeof __VLS_components.nDrawer, ]} */ ;
// @ts-ignore
const __VLS_1 = __VLS_asFunctionalComponent(__VLS_0, new __VLS_0({
    ...{ 'onMaskClick': {} },
    show: (__VLS_ctx.show),
    width: (460),
    placement: "right",
}));
const __VLS_2 = __VLS_1({
    ...{ 'onMaskClick': {} },
    show: (__VLS_ctx.show),
    width: (460),
    placement: "right",
}, ...__VLS_functionalComponentArgsRest(__VLS_1));
let __VLS_4;
let __VLS_5;
let __VLS_6;
const __VLS_7 = {
    onMaskClick: (...[$event]) => {
        __VLS_ctx.emit('close');
    }
};
var __VLS_8 = {};
__VLS_3.slots.default;
const __VLS_9 = {}.NDrawerContent;
/** @type {[typeof __VLS_components.NDrawerContent, typeof __VLS_components.nDrawerContent, typeof __VLS_components.NDrawerContent, typeof __VLS_components.nDrawerContent, ]} */ ;
// @ts-ignore
const __VLS_10 = __VLS_asFunctionalComponent(__VLS_9, new __VLS_9({
    ...{ 'onClose': {} },
    title: (__VLS_ctx.tunnel ? '编辑隧道' : '创建新隧道'),
    closable: true,
}));
const __VLS_11 = __VLS_10({
    ...{ 'onClose': {} },
    title: (__VLS_ctx.tunnel ? '编辑隧道' : '创建新隧道'),
    closable: true,
}, ...__VLS_functionalComponentArgsRest(__VLS_10));
let __VLS_13;
let __VLS_14;
let __VLS_15;
const __VLS_16 = {
    onClose: (...[$event]) => {
        __VLS_ctx.emit('close');
    }
};
__VLS_12.slots.default;
__VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
    ...{ class: "drawer-intro" },
});
__VLS_asFunctionalElement(__VLS_intrinsicElements.b, __VLS_intrinsicElements.b)({});
(__VLS_ctx.tunnel ? '更新连接参数' : '将本地服务安全发布到公网');
__VLS_asFunctionalElement(__VLS_intrinsicElements.span, __VLS_intrinsicElements.span)({});
const __VLS_17 = {}.NForm;
/** @type {[typeof __VLS_components.NForm, typeof __VLS_components.nForm, typeof __VLS_components.NForm, typeof __VLS_components.nForm, ]} */ ;
// @ts-ignore
const __VLS_18 = __VLS_asFunctionalComponent(__VLS_17, new __VLS_17({
    ref: "formRef",
    model: (__VLS_ctx.form),
    rules: (__VLS_ctx.rules),
    labelPlacement: "top",
}));
const __VLS_19 = __VLS_18({
    ref: "formRef",
    model: (__VLS_ctx.form),
    rules: (__VLS_ctx.rules),
    labelPlacement: "top",
}, ...__VLS_functionalComponentArgsRest(__VLS_18));
/** @type {typeof __VLS_ctx.formRef} */ ;
var __VLS_21 = {};
__VLS_20.slots.default;
const __VLS_23 = {}.NFormItem;
/** @type {[typeof __VLS_components.NFormItem, typeof __VLS_components.nFormItem, typeof __VLS_components.NFormItem, typeof __VLS_components.nFormItem, ]} */ ;
// @ts-ignore
const __VLS_24 = __VLS_asFunctionalComponent(__VLS_23, new __VLS_23({
    label: "隧道名称",
    path: "name",
}));
const __VLS_25 = __VLS_24({
    label: "隧道名称",
    path: "name",
}, ...__VLS_functionalComponentArgsRest(__VLS_24));
__VLS_26.slots.default;
const __VLS_27 = {}.NInput;
/** @type {[typeof __VLS_components.NInput, typeof __VLS_components.nInput, ]} */ ;
// @ts-ignore
const __VLS_28 = __VLS_asFunctionalComponent(__VLS_27, new __VLS_27({
    value: (__VLS_ctx.form.name),
    maxlength: "32",
    showCount: true,
    placeholder: "例如：开发环境 API",
}));
const __VLS_29 = __VLS_28({
    value: (__VLS_ctx.form.name),
    maxlength: "32",
    showCount: true,
    placeholder: "例如：开发环境 API",
}, ...__VLS_functionalComponentArgsRest(__VLS_28));
var __VLS_26;
__VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
    ...{ class: "form-grid" },
});
const __VLS_31 = {}.NFormItem;
/** @type {[typeof __VLS_components.NFormItem, typeof __VLS_components.nFormItem, typeof __VLS_components.NFormItem, typeof __VLS_components.nFormItem, ]} */ ;
// @ts-ignore
const __VLS_32 = __VLS_asFunctionalComponent(__VLS_31, new __VLS_31({
    label: "协议",
}));
const __VLS_33 = __VLS_32({
    label: "协议",
}, ...__VLS_functionalComponentArgsRest(__VLS_32));
__VLS_34.slots.default;
const __VLS_35 = {}.NSelect;
/** @type {[typeof __VLS_components.NSelect, typeof __VLS_components.nSelect, ]} */ ;
// @ts-ignore
const __VLS_36 = __VLS_asFunctionalComponent(__VLS_35, new __VLS_35({
    value: (__VLS_ctx.form.protocol),
    options: (['https', 'http', 'tcp', 'udp'].map(v => ({ label: v.toUpperCase(), value: v }))),
}));
const __VLS_37 = __VLS_36({
    value: (__VLS_ctx.form.protocol),
    options: (['https', 'http', 'tcp', 'udp'].map(v => ({ label: v.toUpperCase(), value: v }))),
}, ...__VLS_functionalComponentArgsRest(__VLS_36));
var __VLS_34;
const __VLS_39 = {}.NFormItem;
/** @type {[typeof __VLS_components.NFormItem, typeof __VLS_components.nFormItem, typeof __VLS_components.NFormItem, typeof __VLS_components.nFormItem, ]} */ ;
// @ts-ignore
const __VLS_40 = __VLS_asFunctionalComponent(__VLS_39, new __VLS_39({
    label: "边缘节点",
    path: "nodeId",
}));
const __VLS_41 = __VLS_40({
    label: "边缘节点",
    path: "nodeId",
}, ...__VLS_functionalComponentArgsRest(__VLS_40));
__VLS_42.slots.default;
const __VLS_43 = {}.NSelect;
/** @type {[typeof __VLS_components.NSelect, typeof __VLS_components.nSelect, ]} */ ;
// @ts-ignore
const __VLS_44 = __VLS_asFunctionalComponent(__VLS_43, new __VLS_43({
    value: (__VLS_ctx.form.nodeId),
    options: (__VLS_ctx.nodeOptions),
}));
const __VLS_45 = __VLS_44({
    value: (__VLS_ctx.form.nodeId),
    options: (__VLS_ctx.nodeOptions),
}, ...__VLS_functionalComponentArgsRest(__VLS_44));
var __VLS_42;
const __VLS_47 = {}.NFormItem;
/** @type {[typeof __VLS_components.NFormItem, typeof __VLS_components.nFormItem, typeof __VLS_components.NFormItem, typeof __VLS_components.nFormItem, ]} */ ;
// @ts-ignore
const __VLS_48 = __VLS_asFunctionalComponent(__VLS_47, new __VLS_47({
    label: "本地地址",
    path: "localHost",
}));
const __VLS_49 = __VLS_48({
    label: "本地地址",
    path: "localHost",
}, ...__VLS_functionalComponentArgsRest(__VLS_48));
__VLS_50.slots.default;
const __VLS_51 = {}.NInput;
/** @type {[typeof __VLS_components.NInput, typeof __VLS_components.nInput, ]} */ ;
// @ts-ignore
const __VLS_52 = __VLS_asFunctionalComponent(__VLS_51, new __VLS_51({
    value: (__VLS_ctx.form.localHost),
    placeholder: "127.0.0.1",
}));
const __VLS_53 = __VLS_52({
    value: (__VLS_ctx.form.localHost),
    placeholder: "127.0.0.1",
}, ...__VLS_functionalComponentArgsRest(__VLS_52));
var __VLS_50;
__VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
    ...{ class: "form-grid" },
});
const __VLS_55 = {}.NFormItem;
/** @type {[typeof __VLS_components.NFormItem, typeof __VLS_components.nFormItem, typeof __VLS_components.NFormItem, typeof __VLS_components.nFormItem, ]} */ ;
// @ts-ignore
const __VLS_56 = __VLS_asFunctionalComponent(__VLS_55, new __VLS_55({
    label: "本地端口",
}));
const __VLS_57 = __VLS_56({
    label: "本地端口",
}, ...__VLS_functionalComponentArgsRest(__VLS_56));
__VLS_58.slots.default;
const __VLS_59 = {}.NInputNumber;
/** @type {[typeof __VLS_components.NInputNumber, typeof __VLS_components.nInputNumber, ]} */ ;
// @ts-ignore
const __VLS_60 = __VLS_asFunctionalComponent(__VLS_59, new __VLS_59({
    value: (__VLS_ctx.form.localPort),
    min: (1),
    max: (65535),
    ...{ style: {} },
}));
const __VLS_61 = __VLS_60({
    value: (__VLS_ctx.form.localPort),
    min: (1),
    max: (65535),
    ...{ style: {} },
}, ...__VLS_functionalComponentArgsRest(__VLS_60));
var __VLS_58;
const __VLS_63 = {}.NFormItem;
/** @type {[typeof __VLS_components.NFormItem, typeof __VLS_components.nFormItem, typeof __VLS_components.NFormItem, typeof __VLS_components.nFormItem, ]} */ ;
// @ts-ignore
const __VLS_64 = __VLS_asFunctionalComponent(__VLS_63, new __VLS_63({
    label: "远程端口",
}));
const __VLS_65 = __VLS_64({
    label: "远程端口",
}, ...__VLS_functionalComponentArgsRest(__VLS_64));
__VLS_66.slots.default;
const __VLS_67 = {}.NInputNumber;
/** @type {[typeof __VLS_components.NInputNumber, typeof __VLS_components.nInputNumber, ]} */ ;
// @ts-ignore
const __VLS_68 = __VLS_asFunctionalComponent(__VLS_67, new __VLS_67({
    value: (__VLS_ctx.form.remotePort),
    min: (1),
    max: (65535),
    ...{ style: {} },
}));
const __VLS_69 = __VLS_68({
    value: (__VLS_ctx.form.remotePort),
    min: (1),
    max: (65535),
    ...{ style: {} },
}, ...__VLS_functionalComponentArgsRest(__VLS_68));
var __VLS_66;
if (['http', 'https'].includes(__VLS_ctx.form.protocol)) {
    const __VLS_71 = {}.NFormItem;
    /** @type {[typeof __VLS_components.NFormItem, typeof __VLS_components.nFormItem, typeof __VLS_components.NFormItem, typeof __VLS_components.nFormItem, ]} */ ;
    // @ts-ignore
    const __VLS_72 = __VLS_asFunctionalComponent(__VLS_71, new __VLS_71({
        label: "访问域名（可选）",
    }));
    const __VLS_73 = __VLS_72({
        label: "访问域名（可选）",
    }, ...__VLS_functionalComponentArgsRest(__VLS_72));
    __VLS_74.slots.default;
    const __VLS_75 = {}.NInput;
    /** @type {[typeof __VLS_components.NInput, typeof __VLS_components.nInput, ]} */ ;
    // @ts-ignore
    const __VLS_76 = __VLS_asFunctionalComponent(__VLS_75, new __VLS_75({
        value: (__VLS_ctx.form.domain),
        placeholder: "demo.nexious.link",
    }));
    const __VLS_77 = __VLS_76({
        value: (__VLS_ctx.form.domain),
        placeholder: "demo.nexious.link",
    }, ...__VLS_functionalComponentArgsRest(__VLS_76));
    var __VLS_74;
}
var __VLS_20;
{
    const { footer: __VLS_thisSlot } = __VLS_12.slots;
    const __VLS_79 = {}.NSpace;
    /** @type {[typeof __VLS_components.NSpace, typeof __VLS_components.nSpace, typeof __VLS_components.NSpace, typeof __VLS_components.nSpace, ]} */ ;
    // @ts-ignore
    const __VLS_80 = __VLS_asFunctionalComponent(__VLS_79, new __VLS_79({
        justify: "end",
    }));
    const __VLS_81 = __VLS_80({
        justify: "end",
    }, ...__VLS_functionalComponentArgsRest(__VLS_80));
    __VLS_82.slots.default;
    const __VLS_83 = {}.NButton;
    /** @type {[typeof __VLS_components.NButton, typeof __VLS_components.nButton, typeof __VLS_components.NButton, typeof __VLS_components.nButton, ]} */ ;
    // @ts-ignore
    const __VLS_84 = __VLS_asFunctionalComponent(__VLS_83, new __VLS_83({
        ...{ 'onClick': {} },
    }));
    const __VLS_85 = __VLS_84({
        ...{ 'onClick': {} },
    }, ...__VLS_functionalComponentArgsRest(__VLS_84));
    let __VLS_87;
    let __VLS_88;
    let __VLS_89;
    const __VLS_90 = {
        onClick: (...[$event]) => {
            __VLS_ctx.emit('close');
        }
    };
    __VLS_86.slots.default;
    var __VLS_86;
    const __VLS_91 = {}.NButton;
    /** @type {[typeof __VLS_components.NButton, typeof __VLS_components.nButton, typeof __VLS_components.NButton, typeof __VLS_components.nButton, ]} */ ;
    // @ts-ignore
    const __VLS_92 = __VLS_asFunctionalComponent(__VLS_91, new __VLS_91({
        ...{ 'onClick': {} },
        type: "primary",
        loading: (__VLS_ctx.loading),
    }));
    const __VLS_93 = __VLS_92({
        ...{ 'onClick': {} },
        type: "primary",
        loading: (__VLS_ctx.loading),
    }, ...__VLS_functionalComponentArgsRest(__VLS_92));
    let __VLS_95;
    let __VLS_96;
    let __VLS_97;
    const __VLS_98 = {
        onClick: (__VLS_ctx.submit)
    };
    __VLS_94.slots.default;
    (__VLS_ctx.tunnel ? '保存修改' : '创建隧道');
    var __VLS_94;
    var __VLS_82;
}
var __VLS_12;
var __VLS_3;
/** @type {__VLS_StyleScopedClasses['drawer-intro']} */ ;
/** @type {__VLS_StyleScopedClasses['form-grid']} */ ;
/** @type {__VLS_StyleScopedClasses['form-grid']} */ ;
// @ts-ignore
var __VLS_22 = __VLS_21;
var __VLS_dollars;
const __VLS_self = (await import('vue')).defineComponent({
    setup() {
        return {
            NButton: NButton,
            NDrawer: NDrawer,
            NDrawerContent: NDrawerContent,
            NForm: NForm,
            NFormItem: NFormItem,
            NInput: NInput,
            NInputNumber: NInputNumber,
            NSelect: NSelect,
            NSpace: NSpace,
            emit: emit,
            formRef: formRef,
            form: form,
            rules: rules,
            nodeOptions: nodeOptions,
            submit: submit,
        };
    },
    __typeEmits: {},
    __typeProps: {},
});
export default (await import('vue')).defineComponent({
    setup() {
        return {};
    },
    __typeEmits: {},
    __typeProps: {},
});
; /* PartiallyEnd: #4569/main.vue */
