import { computed, h, ref } from 'vue';
import { NConfigProvider, NDialogProvider, NIcon, NLayout, NLayoutContent, NLayoutSider, NMenu, NMessageProvider, NNotificationProvider, darkTheme } from 'naive-ui';
import { Activity, BookOpenText, Cable, ChevronLeft, CircleGauge, MapPin, Moon, Settings, Sun, Zap } from 'lucide-vue-next';
import { useRoute, useRouter } from 'vue-router';
const collapsed = ref(false), route = useRoute(), router = useRouter(), isDark = ref(localStorage.getItem('nexious-theme') !== 'light');
function toggleTheme() { isDark.value = !isDark.value; localStorage.setItem('nexious-theme', isDark.value ? 'dark' : 'light'); }
const icon = (component) => () => h(NIcon, null, { default: () => h(component) });
const menu = [
    { label: '运行总览', key: '/', icon: icon(CircleGauge) }, { label: '隧道管理', key: '/tunnels', icon: icon(Cable) },
    { label: '边缘节点', key: '/nodes', icon: icon(MapPin) }, { label: '访问日志', key: '/logs', icon: icon(BookOpenText) },
    { type: 'divider', key: 'd' }, { label: '偏好设置', key: '/settings', icon: icon(Settings) }
];
const mobileMenu = [
    { label: '总览', path: '/', icon: CircleGauge }, { label: '隧道', path: '/tunnels', icon: Cable },
    { label: '节点', path: '/nodes', icon: MapPin }, { label: '日志', path: '/logs', icon: BookOpenText },
    { label: '设置', path: '/settings', icon: Settings },
];
const active = computed(() => route.path);
debugger; /* PartiallyEnd: #3632/scriptSetup.vue */
const __VLS_ctx = {};
let __VLS_components;
let __VLS_directives;
const __VLS_0 = {}.NConfigProvider;
/** @type {[typeof __VLS_components.NConfigProvider, typeof __VLS_components.nConfigProvider, typeof __VLS_components.NConfigProvider, typeof __VLS_components.nConfigProvider, ]} */ ;
// @ts-ignore
const __VLS_1 = __VLS_asFunctionalComponent(__VLS_0, new __VLS_0({
    theme: (__VLS_ctx.isDark ? __VLS_ctx.darkTheme : null),
    themeOverrides: ({ common: { primaryColor: '#239b61', primaryColorHover: '#2ebd78', primaryColorPressed: '#187a4b', borderRadius: '6px', fontFamily: '\'IBM Plex Sans\',\'Microsoft YaHei\',sans-serif' } }),
}));
const __VLS_2 = __VLS_1({
    theme: (__VLS_ctx.isDark ? __VLS_ctx.darkTheme : null),
    themeOverrides: ({ common: { primaryColor: '#239b61', primaryColorHover: '#2ebd78', primaryColorPressed: '#187a4b', borderRadius: '6px', fontFamily: '\'IBM Plex Sans\',\'Microsoft YaHei\',sans-serif' } }),
}, ...__VLS_functionalComponentArgsRest(__VLS_1));
var __VLS_4 = {};
__VLS_3.slots.default;
const __VLS_5 = {}.NDialogProvider;
/** @type {[typeof __VLS_components.NDialogProvider, typeof __VLS_components.nDialogProvider, typeof __VLS_components.NDialogProvider, typeof __VLS_components.nDialogProvider, ]} */ ;
// @ts-ignore
const __VLS_6 = __VLS_asFunctionalComponent(__VLS_5, new __VLS_5({}));
const __VLS_7 = __VLS_6({}, ...__VLS_functionalComponentArgsRest(__VLS_6));
__VLS_8.slots.default;
const __VLS_9 = {}.NNotificationProvider;
/** @type {[typeof __VLS_components.NNotificationProvider, typeof __VLS_components.nNotificationProvider, typeof __VLS_components.NNotificationProvider, typeof __VLS_components.nNotificationProvider, ]} */ ;
// @ts-ignore
const __VLS_10 = __VLS_asFunctionalComponent(__VLS_9, new __VLS_9({}));
const __VLS_11 = __VLS_10({}, ...__VLS_functionalComponentArgsRest(__VLS_10));
__VLS_12.slots.default;
const __VLS_13 = {}.NMessageProvider;
/** @type {[typeof __VLS_components.NMessageProvider, typeof __VLS_components.nMessageProvider, typeof __VLS_components.NMessageProvider, typeof __VLS_components.nMessageProvider, ]} */ ;
// @ts-ignore
const __VLS_14 = __VLS_asFunctionalComponent(__VLS_13, new __VLS_13({}));
const __VLS_15 = __VLS_14({}, ...__VLS_functionalComponentArgsRest(__VLS_14));
__VLS_16.slots.default;
const __VLS_17 = {}.NLayout;
/** @type {[typeof __VLS_components.NLayout, typeof __VLS_components.nLayout, typeof __VLS_components.NLayout, typeof __VLS_components.nLayout, ]} */ ;
// @ts-ignore
const __VLS_18 = __VLS_asFunctionalComponent(__VLS_17, new __VLS_17({
    hasSider: true,
    ...{ class: "shell" },
    ...{ class: ({ 'theme-light': !__VLS_ctx.isDark }) },
}));
const __VLS_19 = __VLS_18({
    hasSider: true,
    ...{ class: "shell" },
    ...{ class: ({ 'theme-light': !__VLS_ctx.isDark }) },
}, ...__VLS_functionalComponentArgsRest(__VLS_18));
__VLS_20.slots.default;
const __VLS_21 = {}.NLayoutSider;
/** @type {[typeof __VLS_components.NLayoutSider, typeof __VLS_components.nLayoutSider, typeof __VLS_components.NLayoutSider, typeof __VLS_components.nLayoutSider, ]} */ ;
// @ts-ignore
const __VLS_22 = __VLS_asFunctionalComponent(__VLS_21, new __VLS_21({
    bordered: true,
    collapseMode: "width",
    collapsedWidth: (72),
    width: (232),
    collapsed: (__VLS_ctx.collapsed),
    ...{ class: "sidebar" },
}));
const __VLS_23 = __VLS_22({
    bordered: true,
    collapseMode: "width",
    collapsedWidth: (72),
    width: (232),
    collapsed: (__VLS_ctx.collapsed),
    ...{ class: "sidebar" },
}, ...__VLS_functionalComponentArgsRest(__VLS_22));
__VLS_24.slots.default;
__VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
    ...{ class: "brand" },
    ...{ class: ({ compact: __VLS_ctx.collapsed }) },
});
__VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
    ...{ class: "brand-mark" },
});
const __VLS_25 = {}.Zap;
/** @type {[typeof __VLS_components.Zap, ]} */ ;
// @ts-ignore
const __VLS_26 = __VLS_asFunctionalComponent(__VLS_25, new __VLS_25({
    size: (20),
    fill: "currentColor",
}));
const __VLS_27 = __VLS_26({
    size: (20),
    fill: "currentColor",
}, ...__VLS_functionalComponentArgsRest(__VLS_26));
if (!__VLS_ctx.collapsed) {
    __VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({});
    __VLS_asFunctionalElement(__VLS_intrinsicElements.strong, __VLS_intrinsicElements.strong)({});
    __VLS_asFunctionalElement(__VLS_intrinsicElements.span, __VLS_intrinsicElements.span)({});
}
__VLS_asFunctionalElement(__VLS_intrinsicElements.button, __VLS_intrinsicElements.button)({
    ...{ onClick: (__VLS_ctx.toggleTheme) },
    ...{ class: "theme-button" },
    'aria-label': (__VLS_ctx.isDark ? '切换到白色主题' : '切换到黑色主题'),
    title: (__VLS_ctx.isDark ? '白色主题' : '黑色主题'),
});
if (__VLS_ctx.isDark) {
    const __VLS_29 = {}.Sun;
    /** @type {[typeof __VLS_components.Sun, ]} */ ;
    // @ts-ignore
    const __VLS_30 = __VLS_asFunctionalComponent(__VLS_29, new __VLS_29({
        size: (16),
    }));
    const __VLS_31 = __VLS_30({
        size: (16),
    }, ...__VLS_functionalComponentArgsRest(__VLS_30));
}
else {
    const __VLS_33 = {}.Moon;
    /** @type {[typeof __VLS_components.Moon, ]} */ ;
    // @ts-ignore
    const __VLS_34 = __VLS_asFunctionalComponent(__VLS_33, new __VLS_33({
        size: (16),
    }));
    const __VLS_35 = __VLS_34({
        size: (16),
    }, ...__VLS_functionalComponentArgsRest(__VLS_34));
}
const __VLS_37 = {}.NMenu;
/** @type {[typeof __VLS_components.NMenu, typeof __VLS_components.nMenu, ]} */ ;
// @ts-ignore
const __VLS_38 = __VLS_asFunctionalComponent(__VLS_37, new __VLS_37({
    ...{ 'onUpdate:value': {} },
    collapsed: (__VLS_ctx.collapsed),
    collapsedWidth: (72),
    collapsedIconSize: (21),
    value: (__VLS_ctx.active),
    options: (__VLS_ctx.menu),
}));
const __VLS_39 = __VLS_38({
    ...{ 'onUpdate:value': {} },
    collapsed: (__VLS_ctx.collapsed),
    collapsedWidth: (72),
    collapsedIconSize: (21),
    value: (__VLS_ctx.active),
    options: (__VLS_ctx.menu),
}, ...__VLS_functionalComponentArgsRest(__VLS_38));
let __VLS_41;
let __VLS_42;
let __VLS_43;
const __VLS_44 = {
    'onUpdate:value': ((v) => __VLS_ctx.router.push(v))
};
var __VLS_40;
__VLS_asFunctionalElement(__VLS_intrinsicElements.button, __VLS_intrinsicElements.button)({
    ...{ onClick: (...[$event]) => {
            __VLS_ctx.collapsed = !__VLS_ctx.collapsed;
        } },
    ...{ class: "collapse-button" },
    'aria-label': (__VLS_ctx.collapsed ? '展开侧栏' : '收起侧栏'),
});
const __VLS_45 = {}.ChevronLeft;
/** @type {[typeof __VLS_components.ChevronLeft, ]} */ ;
// @ts-ignore
const __VLS_46 = __VLS_asFunctionalComponent(__VLS_45, new __VLS_45({
    size: (17),
    ...{ class: ({ flip: __VLS_ctx.collapsed }) },
}));
const __VLS_47 = __VLS_46({
    size: (17),
    ...{ class: ({ flip: __VLS_ctx.collapsed }) },
}, ...__VLS_functionalComponentArgsRest(__VLS_46));
if (!__VLS_ctx.collapsed) {
    __VLS_asFunctionalElement(__VLS_intrinsicElements.span, __VLS_intrinsicElements.span)({});
}
if (!__VLS_ctx.collapsed) {
    __VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
        ...{ class: "daemon" },
    });
    __VLS_asFunctionalElement(__VLS_intrinsicElements.i, __VLS_intrinsicElements.i)({});
    __VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({});
    __VLS_asFunctionalElement(__VLS_intrinsicElements.b, __VLS_intrinsicElements.b)({});
    __VLS_asFunctionalElement(__VLS_intrinsicElements.span, __VLS_intrinsicElements.span)({});
    const __VLS_49 = {}.Activity;
    /** @type {[typeof __VLS_components.Activity, ]} */ ;
    // @ts-ignore
    const __VLS_50 = __VLS_asFunctionalComponent(__VLS_49, new __VLS_49({
        size: (16),
    }));
    const __VLS_51 = __VLS_50({
        size: (16),
    }, ...__VLS_functionalComponentArgsRest(__VLS_50));
}
var __VLS_24;
const __VLS_53 = {}.NLayout;
/** @type {[typeof __VLS_components.NLayout, typeof __VLS_components.nLayout, typeof __VLS_components.NLayout, typeof __VLS_components.nLayout, ]} */ ;
// @ts-ignore
const __VLS_54 = __VLS_asFunctionalComponent(__VLS_53, new __VLS_53({}));
const __VLS_55 = __VLS_54({}, ...__VLS_functionalComponentArgsRest(__VLS_54));
__VLS_56.slots.default;
const __VLS_57 = {}.NLayoutContent;
/** @type {[typeof __VLS_components.NLayoutContent, typeof __VLS_components.nLayoutContent, typeof __VLS_components.NLayoutContent, typeof __VLS_components.nLayoutContent, ]} */ ;
// @ts-ignore
const __VLS_58 = __VLS_asFunctionalComponent(__VLS_57, new __VLS_57({
    ...{ class: "content" },
}));
const __VLS_59 = __VLS_58({
    ...{ class: "content" },
}, ...__VLS_functionalComponentArgsRest(__VLS_58));
__VLS_60.slots.default;
const __VLS_61 = {}.RouterView;
/** @type {[typeof __VLS_components.RouterView, typeof __VLS_components.routerView, ]} */ ;
// @ts-ignore
const __VLS_62 = __VLS_asFunctionalComponent(__VLS_61, new __VLS_61({}));
const __VLS_63 = __VLS_62({}, ...__VLS_functionalComponentArgsRest(__VLS_62));
var __VLS_60;
var __VLS_56;
__VLS_asFunctionalElement(__VLS_intrinsicElements.nav, __VLS_intrinsicElements.nav)({
    ...{ class: "mobile-nav" },
});
for (const [item] of __VLS_getVForSourceType((__VLS_ctx.mobileMenu))) {
    __VLS_asFunctionalElement(__VLS_intrinsicElements.button, __VLS_intrinsicElements.button)({
        ...{ onClick: (...[$event]) => {
                __VLS_ctx.router.push(item.path);
            } },
        key: (item.path),
        ...{ class: ({ active: __VLS_ctx.active === item.path }) },
    });
    const __VLS_65 = ((item.icon));
    // @ts-ignore
    const __VLS_66 = __VLS_asFunctionalComponent(__VLS_65, new __VLS_65({}));
    const __VLS_67 = __VLS_66({}, ...__VLS_functionalComponentArgsRest(__VLS_66));
    __VLS_asFunctionalElement(__VLS_intrinsicElements.span, __VLS_intrinsicElements.span)({});
    (item.label);
}
var __VLS_20;
var __VLS_16;
var __VLS_12;
var __VLS_8;
var __VLS_3;
/** @type {__VLS_StyleScopedClasses['shell']} */ ;
/** @type {__VLS_StyleScopedClasses['theme-light']} */ ;
/** @type {__VLS_StyleScopedClasses['sidebar']} */ ;
/** @type {__VLS_StyleScopedClasses['brand']} */ ;
/** @type {__VLS_StyleScopedClasses['compact']} */ ;
/** @type {__VLS_StyleScopedClasses['brand-mark']} */ ;
/** @type {__VLS_StyleScopedClasses['theme-button']} */ ;
/** @type {__VLS_StyleScopedClasses['collapse-button']} */ ;
/** @type {__VLS_StyleScopedClasses['flip']} */ ;
/** @type {__VLS_StyleScopedClasses['daemon']} */ ;
/** @type {__VLS_StyleScopedClasses['content']} */ ;
/** @type {__VLS_StyleScopedClasses['mobile-nav']} */ ;
/** @type {__VLS_StyleScopedClasses['active']} */ ;
var __VLS_dollars;
const __VLS_self = (await import('vue')).defineComponent({
    setup() {
        return {
            NConfigProvider: NConfigProvider,
            NDialogProvider: NDialogProvider,
            NLayout: NLayout,
            NLayoutContent: NLayoutContent,
            NLayoutSider: NLayoutSider,
            NMenu: NMenu,
            NMessageProvider: NMessageProvider,
            NNotificationProvider: NNotificationProvider,
            darkTheme: darkTheme,
            Activity: Activity,
            ChevronLeft: ChevronLeft,
            Moon: Moon,
            Sun: Sun,
            Zap: Zap,
            collapsed: collapsed,
            router: router,
            isDark: isDark,
            toggleTheme: toggleTheme,
            menu: menu,
            mobileMenu: mobileMenu,
            active: active,
        };
    },
});
export default (await import('vue')).defineComponent({
    setup() {
        return {};
    },
});
; /* PartiallyEnd: #4569/main.vue */
