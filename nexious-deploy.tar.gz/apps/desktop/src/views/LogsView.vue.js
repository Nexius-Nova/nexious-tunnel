import { computed, h, ref } from 'vue';
import { useQuery } from '@tanstack/vue-query';
import { NDataTable, NSelect, NTag } from 'naive-ui';
import { api } from '../api/client';
import PageHeader from '../components/PageHeader.vue';
import StateBlock from '../components/StateBlock.vue';
const selected = ref('all');
const tunnels = useQuery({ queryKey: ['tunnels'], queryFn: api.tunnels });
const logs = useQuery({ queryKey: ['logs', selected], queryFn: () => api.logs(selected.value === 'all' ? undefined : selected.value) });
const options = computed(() => [{ label: '全部隧道', value: 'all' }, ...(tunnels.data.value || []).map((tunnel) => ({ label: tunnel.name, value: tunnel.id }))]);
const columns = [
    { title: '时间', key: 'timestamp', render: (row) => new Date(row.timestamp).toLocaleString('zh-CN') },
    { title: '来源 IP', key: 'client_ip' }, { title: '请求', key: 'path', render: (row) => `${row.method}  ${row.path}` },
    { title: '状态码', key: 'status', render: (row) => h(NTag, { size: 'small', type: row.status < 400 ? 'success' : 'error', bordered: false }, { default: () => row.status }) },
    { title: '耗时', key: 'duration', render: (row) => `${row.duration} ms` }, { title: '流量', key: 'bytes', render: (row) => `${(row.bytes / 1024).toFixed(1)} KB` },
];
debugger; /* PartiallyEnd: #3632/scriptSetup.vue */
const __VLS_ctx = {};
let __VLS_components;
let __VLS_directives;
__VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
    ...{ class: "view" },
});
/** @type {[typeof PageHeader, typeof PageHeader, ]} */ ;
// @ts-ignore
const __VLS_0 = __VLS_asFunctionalComponent(PageHeader, new PageHeader({
    eyebrow: "ACCESS OBSERVATORY",
    title: "访问日志",
    description: "追踪每次穿透请求的来源、状态与响应耗时。",
}));
const __VLS_1 = __VLS_0({
    eyebrow: "ACCESS OBSERVATORY",
    title: "访问日志",
    description: "追踪每次穿透请求的来源、状态与响应耗时。",
}, ...__VLS_functionalComponentArgsRest(__VLS_0));
__VLS_2.slots.default;
const __VLS_3 = {}.NSelect;
/** @type {[typeof __VLS_components.NSelect, typeof __VLS_components.nSelect, ]} */ ;
// @ts-ignore
const __VLS_4 = __VLS_asFunctionalComponent(__VLS_3, new __VLS_3({
    value: (__VLS_ctx.selected),
    options: (__VLS_ctx.options),
    ...{ style: {} },
}));
const __VLS_5 = __VLS_4({
    value: (__VLS_ctx.selected),
    options: (__VLS_ctx.options),
    ...{ style: {} },
}, ...__VLS_functionalComponentArgsRest(__VLS_4));
var __VLS_2;
if (__VLS_ctx.logs.isLoading.value || __VLS_ctx.logs.error.value || !__VLS_ctx.logs.data.value?.length) {
    /** @type {[typeof StateBlock, ]} */ ;
    // @ts-ignore
    const __VLS_7 = __VLS_asFunctionalComponent(StateBlock, new StateBlock({
        loading: (__VLS_ctx.logs.isLoading.value),
        error: (__VLS_ctx.logs.error.value?.message),
        empty: (!__VLS_ctx.logs.isLoading.value && !__VLS_ctx.logs.error.value && !__VLS_ctx.logs.data.value?.length),
    }));
    const __VLS_8 = __VLS_7({
        loading: (__VLS_ctx.logs.isLoading.value),
        error: (__VLS_ctx.logs.error.value?.message),
        empty: (!__VLS_ctx.logs.isLoading.value && !__VLS_ctx.logs.error.value && !__VLS_ctx.logs.data.value?.length),
    }, ...__VLS_functionalComponentArgsRest(__VLS_7));
}
else {
    __VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
        ...{ class: "table-panel" },
    });
    const __VLS_10 = {}.NDataTable;
    /** @type {[typeof __VLS_components.NDataTable, typeof __VLS_components.nDataTable, ]} */ ;
    // @ts-ignore
    const __VLS_11 = __VLS_asFunctionalComponent(__VLS_10, new __VLS_10({
        data: (__VLS_ctx.logs.data.value),
        columns: (__VLS_ctx.columns),
        bordered: (false),
    }));
    const __VLS_12 = __VLS_11({
        data: (__VLS_ctx.logs.data.value),
        columns: (__VLS_ctx.columns),
        bordered: (false),
    }, ...__VLS_functionalComponentArgsRest(__VLS_11));
}
/** @type {__VLS_StyleScopedClasses['view']} */ ;
/** @type {__VLS_StyleScopedClasses['table-panel']} */ ;
var __VLS_dollars;
const __VLS_self = (await import('vue')).defineComponent({
    setup() {
        return {
            NDataTable: NDataTable,
            NSelect: NSelect,
            PageHeader: PageHeader,
            StateBlock: StateBlock,
            selected: selected,
            logs: logs,
            options: options,
            columns: columns,
        };
    },
});
export default (await import('vue')).defineComponent({
    setup() {
        return {};
    },
});
; /* PartiallyEnd: #4569/main.vue */
