import { reactive, watch } from 'vue';
import { useMutation, useQuery } from '@tanstack/vue-query';
import { NButton, NRadioButton, NRadioGroup, NSwitch, useMessage } from 'naive-ui';
import { Bell, Download, MonitorUp, PanelTopClose } from 'lucide-vue-next';
import { api } from '../api/client';
import PageHeader from '../components/PageHeader.vue';
import StateBlock from '../components/StateBlock.vue';
const message = useMessage(), query = useQuery({ queryKey: ['settings'], queryFn: api.settings }), form = reactive({ autoStart: true, minimizeToTray: true, notifications: true, updateChannel: 'stable' });
watch(() => query.data.value, v => v && Object.assign(form, v));
const save = useMutation({ mutationFn: api.saveSettings, onSuccess: () => message.success('偏好设置已保存'), onError: e => message.error(e.message) });
const items = [{ key: 'autoStart', title: '开机自动启动', desc: '登录系统后自动启动 Nexious Tunnel', icon: MonitorUp }, { key: 'minimizeToTray', title: '关闭时最小化到托盘', desc: '保持隧道在后台持续运行', icon: PanelTopClose }, { key: 'notifications', title: '桌面通知', desc: '隧道断开或恢复时发送系统通知', icon: Bell }];
debugger; /* PartiallyEnd: #3632/scriptSetup.vue */
const __VLS_ctx = {};
let __VLS_components;
let __VLS_directives;
__VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
    ...{ class: "view settings-view" },
});
/** @type {[typeof PageHeader, ]} */ ;
// @ts-ignore
const __VLS_0 = __VLS_asFunctionalComponent(PageHeader, new PageHeader({
    eyebrow: "APPLICATION",
    title: "偏好设置",
    description: "管理桌面客户端的启动、通知与更新策略。",
}));
const __VLS_1 = __VLS_0({
    eyebrow: "APPLICATION",
    title: "偏好设置",
    description: "管理桌面客户端的启动、通知与更新策略。",
}, ...__VLS_functionalComponentArgsRest(__VLS_0));
if (__VLS_ctx.query.isLoading.value || __VLS_ctx.query.error.value) {
    /** @type {[typeof StateBlock, ]} */ ;
    // @ts-ignore
    const __VLS_3 = __VLS_asFunctionalComponent(StateBlock, new StateBlock({
        loading: (__VLS_ctx.query.isLoading.value),
        error: (__VLS_ctx.query.error.value?.message),
    }));
    const __VLS_4 = __VLS_3({
        loading: (__VLS_ctx.query.isLoading.value),
        error: (__VLS_ctx.query.error.value?.message),
    }, ...__VLS_functionalComponentArgsRest(__VLS_3));
}
else {
    __VLS_asFunctionalElement(__VLS_intrinsicElements.section, __VLS_intrinsicElements.section)({
        ...{ class: "settings-panel" },
    });
    __VLS_asFunctionalElement(__VLS_intrinsicElements.h2, __VLS_intrinsicElements.h2)({});
    for (const [item] of __VLS_getVForSourceType((__VLS_ctx.items))) {
        __VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
            key: (item.key),
            ...{ class: "setting-row" },
        });
        __VLS_asFunctionalElement(__VLS_intrinsicElements.i, __VLS_intrinsicElements.i)({});
        const __VLS_6 = ((item.icon));
        // @ts-ignore
        const __VLS_7 = __VLS_asFunctionalComponent(__VLS_6, new __VLS_6({}));
        const __VLS_8 = __VLS_7({}, ...__VLS_functionalComponentArgsRest(__VLS_7));
        __VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({});
        __VLS_asFunctionalElement(__VLS_intrinsicElements.b, __VLS_intrinsicElements.b)({});
        (item.title);
        __VLS_asFunctionalElement(__VLS_intrinsicElements.span, __VLS_intrinsicElements.span)({});
        (item.desc);
        const __VLS_10 = {}.NSwitch;
        /** @type {[typeof __VLS_components.NSwitch, typeof __VLS_components.nSwitch, ]} */ ;
        // @ts-ignore
        const __VLS_11 = __VLS_asFunctionalComponent(__VLS_10, new __VLS_10({
            value: (__VLS_ctx.form[item.key]),
        }));
        const __VLS_12 = __VLS_11({
            value: (__VLS_ctx.form[item.key]),
        }, ...__VLS_functionalComponentArgsRest(__VLS_11));
    }
    __VLS_asFunctionalElement(__VLS_intrinsicElements.section, __VLS_intrinsicElements.section)({
        ...{ class: "settings-panel" },
    });
    __VLS_asFunctionalElement(__VLS_intrinsicElements.h2, __VLS_intrinsicElements.h2)({});
    __VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
        ...{ class: "setting-row" },
    });
    __VLS_asFunctionalElement(__VLS_intrinsicElements.i, __VLS_intrinsicElements.i)({});
    const __VLS_14 = {}.Download;
    /** @type {[typeof __VLS_components.Download, ]} */ ;
    // @ts-ignore
    const __VLS_15 = __VLS_asFunctionalComponent(__VLS_14, new __VLS_14({}));
    const __VLS_16 = __VLS_15({}, ...__VLS_functionalComponentArgsRest(__VLS_15));
    __VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({});
    __VLS_asFunctionalElement(__VLS_intrinsicElements.b, __VLS_intrinsicElements.b)({});
    __VLS_asFunctionalElement(__VLS_intrinsicElements.span, __VLS_intrinsicElements.span)({});
    const __VLS_18 = {}.NRadioGroup;
    /** @type {[typeof __VLS_components.NRadioGroup, typeof __VLS_components.nRadioGroup, typeof __VLS_components.NRadioGroup, typeof __VLS_components.nRadioGroup, ]} */ ;
    // @ts-ignore
    const __VLS_19 = __VLS_asFunctionalComponent(__VLS_18, new __VLS_18({
        value: (__VLS_ctx.form.updateChannel),
        size: "small",
    }));
    const __VLS_20 = __VLS_19({
        value: (__VLS_ctx.form.updateChannel),
        size: "small",
    }, ...__VLS_functionalComponentArgsRest(__VLS_19));
    __VLS_21.slots.default;
    const __VLS_22 = {}.NRadioButton;
    /** @type {[typeof __VLS_components.NRadioButton, typeof __VLS_components.nRadioButton, typeof __VLS_components.NRadioButton, typeof __VLS_components.nRadioButton, ]} */ ;
    // @ts-ignore
    const __VLS_23 = __VLS_asFunctionalComponent(__VLS_22, new __VLS_22({
        value: "stable",
    }));
    const __VLS_24 = __VLS_23({
        value: "stable",
    }, ...__VLS_functionalComponentArgsRest(__VLS_23));
    __VLS_25.slots.default;
    var __VLS_25;
    const __VLS_26 = {}.NRadioButton;
    /** @type {[typeof __VLS_components.NRadioButton, typeof __VLS_components.nRadioButton, typeof __VLS_components.NRadioButton, typeof __VLS_components.nRadioButton, ]} */ ;
    // @ts-ignore
    const __VLS_27 = __VLS_asFunctionalComponent(__VLS_26, new __VLS_26({
        value: "beta",
    }));
    const __VLS_28 = __VLS_27({
        value: "beta",
    }, ...__VLS_functionalComponentArgsRest(__VLS_27));
    __VLS_29.slots.default;
    var __VLS_29;
    var __VLS_21;
    __VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
        ...{ class: "save-bar" },
    });
    __VLS_asFunctionalElement(__VLS_intrinsicElements.span, __VLS_intrinsicElements.span)({});
    const __VLS_30 = {}.NButton;
    /** @type {[typeof __VLS_components.NButton, typeof __VLS_components.nButton, typeof __VLS_components.NButton, typeof __VLS_components.nButton, ]} */ ;
    // @ts-ignore
    const __VLS_31 = __VLS_asFunctionalComponent(__VLS_30, new __VLS_30({
        ...{ 'onClick': {} },
        type: "primary",
        loading: (__VLS_ctx.save.isPending.value),
    }));
    const __VLS_32 = __VLS_31({
        ...{ 'onClick': {} },
        type: "primary",
        loading: (__VLS_ctx.save.isPending.value),
    }, ...__VLS_functionalComponentArgsRest(__VLS_31));
    let __VLS_34;
    let __VLS_35;
    let __VLS_36;
    const __VLS_37 = {
        onClick: (...[$event]) => {
            if (!!(__VLS_ctx.query.isLoading.value || __VLS_ctx.query.error.value))
                return;
            __VLS_ctx.save.mutate({ ...__VLS_ctx.form });
        }
    };
    __VLS_33.slots.default;
    var __VLS_33;
}
/** @type {__VLS_StyleScopedClasses['view']} */ ;
/** @type {__VLS_StyleScopedClasses['settings-view']} */ ;
/** @type {__VLS_StyleScopedClasses['settings-panel']} */ ;
/** @type {__VLS_StyleScopedClasses['setting-row']} */ ;
/** @type {__VLS_StyleScopedClasses['settings-panel']} */ ;
/** @type {__VLS_StyleScopedClasses['setting-row']} */ ;
/** @type {__VLS_StyleScopedClasses['save-bar']} */ ;
var __VLS_dollars;
const __VLS_self = (await import('vue')).defineComponent({
    setup() {
        return {
            NButton: NButton,
            NRadioButton: NRadioButton,
            NRadioGroup: NRadioGroup,
            NSwitch: NSwitch,
            Download: Download,
            PageHeader: PageHeader,
            StateBlock: StateBlock,
            query: query,
            form: form,
            save: save,
            items: items,
        };
    },
});
export default (await import('vue')).defineComponent({
    setup() {
        return {};
    },
});
; /* PartiallyEnd: #4569/main.vue */
