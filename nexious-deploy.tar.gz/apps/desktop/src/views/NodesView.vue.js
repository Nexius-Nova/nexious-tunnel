import { useQuery } from '@tanstack/vue-query';
import { NProgress, NTag } from 'naive-ui';
import { Clock3, MapPin, Server } from 'lucide-vue-next';
import { api } from '../api/client';
import PageHeader from '../components/PageHeader.vue';
import StateBlock from '../components/StateBlock.vue';
const query = useQuery({ queryKey: ['nodes'], queryFn: api.nodes });
debugger; /* PartiallyEnd: #3632/scriptSetup.vue */
const __VLS_ctx = {};
let __VLS_components;
let __VLS_directives;
__VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
    ...{ class: "view" },
});
/** @type {[typeof PageHeader, ]} */ ;
// @ts-ignore
const __VLS_0 = __VLS_asFunctionalComponent(PageHeader, new PageHeader({
    eyebrow: "EDGE NETWORK",
    title: "边缘节点",
    description: "选择离用户更近、负载更低的中继节点。",
}));
const __VLS_1 = __VLS_0({
    eyebrow: "EDGE NETWORK",
    title: "边缘节点",
    description: "选择离用户更近、负载更低的中继节点。",
}, ...__VLS_functionalComponentArgsRest(__VLS_0));
if (__VLS_ctx.query.isLoading.value || __VLS_ctx.query.error.value) {
    /** @type {[typeof StateBlock, ]} */ ;
    // @ts-ignore
    const __VLS_3 = __VLS_asFunctionalComponent(StateBlock, new StateBlock({
        loading: (__VLS_ctx.query.isLoading.value),
        error: (__VLS_ctx.query.error.value?.message),
    }));
    const __VLS_4 = __VLS_3({
        loading: (__VLS_ctx.query.isLoading.value),
        error: (__VLS_ctx.query.error.value?.message),
    }, ...__VLS_functionalComponentArgsRest(__VLS_3));
}
else {
    __VLS_asFunctionalElement(__VLS_intrinsicElements.section, __VLS_intrinsicElements.section)({
        ...{ class: "node-grid" },
    });
    for (const [node] of __VLS_getVForSourceType((__VLS_ctx.query.data.value))) {
        __VLS_asFunctionalElement(__VLS_intrinsicElements.article, __VLS_intrinsicElements.article)({
            key: (node.id),
            ...{ class: "node-card" },
        });
        __VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
            ...{ class: "node-top" },
        });
        __VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
            ...{ class: "node-pin" },
        });
        const __VLS_6 = {}.MapPin;
        /** @type {[typeof __VLS_components.MapPin, ]} */ ;
        // @ts-ignore
        const __VLS_7 = __VLS_asFunctionalComponent(__VLS_6, new __VLS_6({}));
        const __VLS_8 = __VLS_7({}, ...__VLS_functionalComponentArgsRest(__VLS_7));
        const __VLS_10 = {}.NTag;
        /** @type {[typeof __VLS_components.NTag, typeof __VLS_components.nTag, typeof __VLS_components.NTag, typeof __VLS_components.nTag, ]} */ ;
        // @ts-ignore
        const __VLS_11 = __VLS_asFunctionalComponent(__VLS_10, new __VLS_10({
            type: (node.status === 'online' ? 'success' : 'warning'),
            bordered: (false),
        }));
        const __VLS_12 = __VLS_11({
            type: (node.status === 'online' ? 'success' : 'warning'),
            bordered: (false),
        }, ...__VLS_functionalComponentArgsRest(__VLS_11));
        __VLS_13.slots.default;
        (node.status === 'online' ? '在线' : '维护中');
        var __VLS_13;
        __VLS_asFunctionalElement(__VLS_intrinsicElements.span, __VLS_intrinsicElements.span)({});
        (node.region);
        __VLS_asFunctionalElement(__VLS_intrinsicElements.h2, __VLS_intrinsicElements.h2)({});
        (node.city);
        __VLS_asFunctionalElement(__VLS_intrinsicElements.p, __VLS_intrinsicElements.p)({});
        (node.name);
        __VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
            ...{ class: "node-stats" },
        });
        __VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({});
        const __VLS_14 = {}.Clock3;
        /** @type {[typeof __VLS_components.Clock3, ]} */ ;
        // @ts-ignore
        const __VLS_15 = __VLS_asFunctionalComponent(__VLS_14, new __VLS_14({}));
        const __VLS_16 = __VLS_15({}, ...__VLS_functionalComponentArgsRest(__VLS_15));
        __VLS_asFunctionalElement(__VLS_intrinsicElements.span, __VLS_intrinsicElements.span)({});
        __VLS_asFunctionalElement(__VLS_intrinsicElements.b, __VLS_intrinsicElements.b)({});
        (node.latency);
        __VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({});
        const __VLS_18 = {}.Server;
        /** @type {[typeof __VLS_components.Server, ]} */ ;
        // @ts-ignore
        const __VLS_19 = __VLS_asFunctionalComponent(__VLS_18, new __VLS_18({}));
        const __VLS_20 = __VLS_19({}, ...__VLS_functionalComponentArgsRest(__VLS_19));
        __VLS_asFunctionalElement(__VLS_intrinsicElements.span, __VLS_intrinsicElements.span)({});
        __VLS_asFunctionalElement(__VLS_intrinsicElements.b, __VLS_intrinsicElements.b)({});
        (node.load);
        const __VLS_22 = {}.NProgress;
        /** @type {[typeof __VLS_components.NProgress, typeof __VLS_components.nProgress, ]} */ ;
        // @ts-ignore
        const __VLS_23 = __VLS_asFunctionalComponent(__VLS_22, new __VLS_22({
            type: "line",
            percentage: (node.load),
            showIndicator: (false),
            color: (node.load > 70 ? '#f3b44d' : '#39d98a'),
            railColor: "#252b2e",
        }));
        const __VLS_24 = __VLS_23({
            type: "line",
            percentage: (node.load),
            showIndicator: (false),
            color: (node.load > 70 ? '#f3b44d' : '#39d98a'),
            railColor: "#252b2e",
        }, ...__VLS_functionalComponentArgsRest(__VLS_23));
        __VLS_asFunctionalElement(__VLS_intrinsicElements.code, __VLS_intrinsicElements.code)({});
        (node.host);
    }
}
/** @type {__VLS_StyleScopedClasses['view']} */ ;
/** @type {__VLS_StyleScopedClasses['node-grid']} */ ;
/** @type {__VLS_StyleScopedClasses['node-card']} */ ;
/** @type {__VLS_StyleScopedClasses['node-top']} */ ;
/** @type {__VLS_StyleScopedClasses['node-pin']} */ ;
/** @type {__VLS_StyleScopedClasses['node-stats']} */ ;
var __VLS_dollars;
const __VLS_self = (await import('vue')).defineComponent({
    setup() {
        return {
            NProgress: NProgress,
            NTag: NTag,
            Clock3: Clock3,
            MapPin: MapPin,
            Server: Server,
            PageHeader: PageHeader,
            StateBlock: StateBlock,
            query: query,
        };
    },
});
export default (await import('vue')).defineComponent({
    setup() {
        return {};
    },
});
; /* PartiallyEnd: #4569/main.vue */
