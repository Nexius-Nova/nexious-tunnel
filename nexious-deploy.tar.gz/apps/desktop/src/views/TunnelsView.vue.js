import { h, ref } from 'vue';
import { useMutation, useQuery, useQueryClient } from '@tanstack/vue-query';
import { NButton, NDataTable, NDropdown, NInput, NTag, useMessage } from 'naive-ui';
import { MoreHorizontal, Plus, Search } from 'lucide-vue-next';
import { api } from '../api/client';
import PageHeader from '../components/PageHeader.vue';
import StateBlock from '../components/StateBlock.vue';
import TunnelDrawer from '../components/TunnelDrawer.vue';
const message = useMessage(), qc = useQueryClient(), search = ref(''), drawer = ref(false), editing = ref(null);
const tunnels = useQuery({ queryKey: ['tunnels'], queryFn: api.tunnels }), nodes = useQuery({ queryKey: ['nodes'], queryFn: api.nodes });
const refresh = () => { qc.invalidateQueries({ queryKey: ['tunnels'] }); qc.invalidateQueries({ queryKey: ['dashboard'] }); };
const save = useMutation({ mutationFn: (v) => editing.value ? api.updateTunnel(editing.value.id, v) : api.createTunnel(v), onSuccess: () => { message.success(editing.value ? '隧道已更新' : '隧道已创建'); drawer.value = false; refresh(); }, onError: (e) => message.error(e.message) });
const status = useMutation({ mutationFn: ({ id, next }) => api.setTunnelStatus(id, next), onSuccess: () => { message.success('运行状态已更新'); refresh(); }, onError: (e) => message.error(e.message) });
const remove = useMutation({ mutationFn: api.deleteTunnel, onSuccess: () => { message.success('隧道已删除'); refresh(); }, onError: (e) => message.error(e.message) });
function open(t = null) { editing.value = t; drawer.value = true; }
;
const filtered = () => tunnels.data.value?.filter(t => `${t.name}${t.local_host}${t.domain}`.toLowerCase().includes(search.value.toLowerCase())) || [];
const columns = [{ title: '隧道', key: 'name', render: t => h('div', { class: 'tunnel-name' }, [h('i', { class: t.status }), h('div', [h('b', t.name), h('span', t.id)])]) }, { title: '协议', key: 'protocol', render: t => h(NTag, { size: 'small', bordered: false }, { default: () => t.protocol.toUpperCase() }) }, { title: '本地服务', key: 'local', render: t => h('code', `${t.local_host}:${t.local_port}`) }, { title: '公网入口', key: 'remote', render: t => h('div', { class: 'endpoint' }, [h('b', t.domain || `${t.node_city}:${t.remote_port}`), h('span', t.node_name)]) }, { title: '状态', key: 'status', render: t => h('span', { class: `status ${t.status}` }, t.status === 'running' ? `运行中 · ${t.latency}ms` : '已停止') }, { title: '操作', key: 'actions', width: 76, render: t => h(NDropdown, { trigger: 'click', options: [{ label: t.status === 'running' ? '停止隧道' : '启动隧道', key: 'toggle' }, { label: '编辑配置', key: 'edit' }, { type: 'divider', key: 'd' }, { label: '删除', key: 'delete' }], onSelect: (key) => { if (key === 'toggle')
                status.mutate({ id: t.id, next: t.status === 'running' ? 'stopped' : 'running' }); if (key === 'edit')
                open(t); if (key === 'delete')
                remove.mutate(t.id); } }, { default: () => h(NButton, { quaternary: true, circle: true }, { icon: () => h(MoreHorizontal) }) }) }];
debugger; /* PartiallyEnd: #3632/scriptSetup.vue */
const __VLS_ctx = {};
let __VLS_components;
let __VLS_directives;
__VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
    ...{ class: "view" },
});
/** @type {[typeof PageHeader, typeof PageHeader, ]} */ ;
// @ts-ignore
const __VLS_0 = __VLS_asFunctionalComponent(PageHeader, new PageHeader({
    eyebrow: "TUNNEL REGISTRY",
    title: "隧道管理",
    description: "配置、发布并监控你的本地服务。",
}));
const __VLS_1 = __VLS_0({
    eyebrow: "TUNNEL REGISTRY",
    title: "隧道管理",
    description: "配置、发布并监控你的本地服务。",
}, ...__VLS_functionalComponentArgsRest(__VLS_0));
__VLS_2.slots.default;
const __VLS_3 = {}.NButton;
/** @type {[typeof __VLS_components.NButton, typeof __VLS_components.nButton, typeof __VLS_components.NButton, typeof __VLS_components.nButton, ]} */ ;
// @ts-ignore
const __VLS_4 = __VLS_asFunctionalComponent(__VLS_3, new __VLS_3({
    ...{ 'onClick': {} },
    type: "primary",
}));
const __VLS_5 = __VLS_4({
    ...{ 'onClick': {} },
    type: "primary",
}, ...__VLS_functionalComponentArgsRest(__VLS_4));
let __VLS_7;
let __VLS_8;
let __VLS_9;
const __VLS_10 = {
    onClick: (...[$event]) => {
        __VLS_ctx.open();
    }
};
__VLS_6.slots.default;
{
    const { icon: __VLS_thisSlot } = __VLS_6.slots;
    const __VLS_11 = {}.Plus;
    /** @type {[typeof __VLS_components.Plus, ]} */ ;
    // @ts-ignore
    const __VLS_12 = __VLS_asFunctionalComponent(__VLS_11, new __VLS_11({}));
    const __VLS_13 = __VLS_12({}, ...__VLS_functionalComponentArgsRest(__VLS_12));
}
var __VLS_6;
var __VLS_2;
__VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
    ...{ class: "toolbar" },
});
const __VLS_15 = {}.NInput;
/** @type {[typeof __VLS_components.NInput, typeof __VLS_components.nInput, typeof __VLS_components.NInput, typeof __VLS_components.nInput, ]} */ ;
// @ts-ignore
const __VLS_16 = __VLS_asFunctionalComponent(__VLS_15, new __VLS_15({
    value: (__VLS_ctx.search),
    clearable: true,
    placeholder: "搜索名称、地址或域名",
}));
const __VLS_17 = __VLS_16({
    value: (__VLS_ctx.search),
    clearable: true,
    placeholder: "搜索名称、地址或域名",
}, ...__VLS_functionalComponentArgsRest(__VLS_16));
__VLS_18.slots.default;
{
    const { prefix: __VLS_thisSlot } = __VLS_18.slots;
    const __VLS_19 = {}.Search;
    /** @type {[typeof __VLS_components.Search, ]} */ ;
    // @ts-ignore
    const __VLS_20 = __VLS_asFunctionalComponent(__VLS_19, new __VLS_19({
        size: (17),
    }));
    const __VLS_21 = __VLS_20({
        size: (17),
    }, ...__VLS_functionalComponentArgsRest(__VLS_20));
}
var __VLS_18;
__VLS_asFunctionalElement(__VLS_intrinsicElements.span, __VLS_intrinsicElements.span)({});
(__VLS_ctx.filtered().length);
if (__VLS_ctx.tunnels.isLoading.value || __VLS_ctx.tunnels.error.value || !__VLS_ctx.filtered().length) {
    /** @type {[typeof StateBlock, ]} */ ;
    // @ts-ignore
    const __VLS_23 = __VLS_asFunctionalComponent(StateBlock, new StateBlock({
        loading: (__VLS_ctx.tunnels.isLoading.value),
        error: (__VLS_ctx.tunnels.error.value?.message),
        empty: (!__VLS_ctx.tunnels.isLoading.value && !__VLS_ctx.tunnels.error.value && !__VLS_ctx.filtered().length),
    }));
    const __VLS_24 = __VLS_23({
        loading: (__VLS_ctx.tunnels.isLoading.value),
        error: (__VLS_ctx.tunnels.error.value?.message),
        empty: (!__VLS_ctx.tunnels.isLoading.value && !__VLS_ctx.tunnels.error.value && !__VLS_ctx.filtered().length),
    }, ...__VLS_functionalComponentArgsRest(__VLS_23));
}
else {
    __VLS_asFunctionalElement(__VLS_intrinsicElements.div, __VLS_intrinsicElements.div)({
        ...{ class: "table-panel" },
    });
    const __VLS_26 = {}.NDataTable;
    /** @type {[typeof __VLS_components.NDataTable, typeof __VLS_components.nDataTable, ]} */ ;
    // @ts-ignore
    const __VLS_27 = __VLS_asFunctionalComponent(__VLS_26, new __VLS_26({
        columns: (__VLS_ctx.columns),
        data: (__VLS_ctx.filtered()),
        bordered: (false),
        singleLine: (false),
    }));
    const __VLS_28 = __VLS_27({
        columns: (__VLS_ctx.columns),
        data: (__VLS_ctx.filtered()),
        bordered: (false),
        singleLine: (false),
    }, ...__VLS_functionalComponentArgsRest(__VLS_27));
}
/** @type {[typeof TunnelDrawer, ]} */ ;
// @ts-ignore
const __VLS_30 = __VLS_asFunctionalComponent(TunnelDrawer, new TunnelDrawer({
    ...{ 'onClose': {} },
    ...{ 'onSubmit': {} },
    show: (__VLS_ctx.drawer),
    tunnel: (__VLS_ctx.editing),
    nodes: (__VLS_ctx.nodes.data.value || []),
    loading: (__VLS_ctx.save.isPending.value),
}));
const __VLS_31 = __VLS_30({
    ...{ 'onClose': {} },
    ...{ 'onSubmit': {} },
    show: (__VLS_ctx.drawer),
    tunnel: (__VLS_ctx.editing),
    nodes: (__VLS_ctx.nodes.data.value || []),
    loading: (__VLS_ctx.save.isPending.value),
}, ...__VLS_functionalComponentArgsRest(__VLS_30));
let __VLS_33;
let __VLS_34;
let __VLS_35;
const __VLS_36 = {
    onClose: (...[$event]) => {
        __VLS_ctx.drawer = false;
    }
};
const __VLS_37 = {
    onSubmit: (__VLS_ctx.save.mutate)
};
var __VLS_32;
/** @type {__VLS_StyleScopedClasses['view']} */ ;
/** @type {__VLS_StyleScopedClasses['toolbar']} */ ;
/** @type {__VLS_StyleScopedClasses['table-panel']} */ ;
var __VLS_dollars;
const __VLS_self = (await import('vue')).defineComponent({
    setup() {
        return {
            NButton: NButton,
            NDataTable: NDataTable,
            NInput: NInput,
            Plus: Plus,
            Search: Search,
            PageHeader: PageHeader,
            StateBlock: StateBlock,
            TunnelDrawer: TunnelDrawer,
            search: search,
            drawer: drawer,
            editing: editing,
            tunnels: tunnels,
            nodes: nodes,
            save: save,
            open: open,
            filtered: filtered,
            columns: columns,
        };
    },
});
export default (await import('vue')).defineComponent({
    setup() {
        return {};
    },
});
; /* PartiallyEnd: #4569/main.vue */
