import cors from 'cors'
import express, { type ErrorRequestHandler } from 'express'
import { createServer } from 'node:http'
import { randomUUID } from 'node:crypto'
import { WebSocketServer, WebSocket } from 'ws'
import { z } from 'zod'
import { db, tunnelRows } from './db.js'

const app = express()
const httpServer = createServer(app)
const port = Number(process.env.PORT || 8787)
app.use(cors())
app.use(express.json())
app.use('/api', (req, res, next) => {
  if (req.path === '/health' || !process.env.NEXIOUS_ADMIN_TOKEN) return next()
  if (req.headers.authorization !== `Bearer ${process.env.NEXIOUS_ADMIN_TOKEN}`) return res.status(401).json({ message: '控制中心认证失败' })
  next()
})
const agents = new Map<string, WebSocket>()
const pending = new Map<string, (payload: any) => void>()

const tunnelSchema = z.object({
  name: z.string().trim().min(2).max(32), protocol: z.enum(['tcp', 'udp', 'http', 'https']),
  localHost: z.string().trim().min(1), localPort: z.number().int().min(1).max(65535),
  remotePort: z.number().int().min(1).max(65535), nodeId: z.string().min(1),
  domain: z.string().trim().max(80).nullable().optional()
})

app.get('/api/health', (_req, res) => res.json({ ok: true, version: '1.0.0', time: new Date().toISOString() }))
app.get('/api/dashboard', (_req, res) => {
  const tunnels = tunnelRows() as Array<Record<string, unknown>>
  const totals = db.prepare('SELECT COALESCE(SUM(inbound),0) inbound, COALESCE(SUM(outbound),0) outbound FROM traffic').get()
  const series = db.prepare(`SELECT timestamp, SUM(inbound) inbound, SUM(outbound) outbound FROM traffic WHERE timestamp > datetime('now','-24 hours') GROUP BY timestamp ORDER BY timestamp`).all()
  const nodeCount = (db.prepare("SELECT COUNT(*) count FROM nodes WHERE status='online'").get() as { count: number }).count
  res.json({ tunnels, totals, series, onlineNodes: nodeCount, activeTunnels: tunnels.filter((t) => t.status === 'running').length })
})
app.get('/api/tunnels', (_req, res) => res.json(tunnelRows()))
app.post('/api/tunnels/:id/token', (req, res) => {
  const tunnel = (tunnelRows() as Array<{id:string}>).find((row) => row.id === req.params.id)
  if (!tunnel) return res.status(404).json({ message: '隧道不存在' })
  const token = randomUUID().replaceAll('-', '')
  db.prepare('UPDATE tunnels SET agent_token=? WHERE id=?').run(token, req.params.id)
  res.json({ token, tunnelId: req.params.id, relay: `${process.env.RELAY_URL || 'ws://127.0.0.1:8787'}/relay` })
})
app.get('/api/tunnels/:id/agent-command', (req, res) => {
  const row = db.prepare('SELECT id,agent_token,local_host,local_port FROM tunnels WHERE id=?').get(req.params.id) as any
  if (!row) return res.status(404).json({ message: '隧道不存在' })
  if (!row.agent_token) return res.status(409).json({ message: '请先生成 agent token' })
  res.json({ command: `pnpm --filter @nexious/agent start -- --relay ${process.env.RELAY_URL || 'ws://127.0.0.1:8787'}/relay --tunnel ${row.id} --token ${row.agent_token} --target http://${row.local_host}:${row.local_port}` })
})
app.post('/api/tunnels', (req, res) => {
  const value = tunnelSchema.parse(req.body)
  const id = `tun-${randomUUID().slice(0, 8)}`
  db.prepare(`INSERT INTO tunnels (id,name,protocol,local_host,local_port,remote_port,node_id,status,domain,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)`)
    .run(id, value.name, value.protocol, value.localHost, value.localPort, value.remotePort, value.nodeId, 'stopped', value.domain || null, new Date().toISOString())
  res.status(201).json((tunnelRows() as Array<{ id: string }>).find((item) => item.id === id))
})
app.put('/api/tunnels/:id', (req, res) => {
  const value = tunnelSchema.parse(req.body)
  const result = db.prepare(`UPDATE tunnels SET name=?,protocol=?,local_host=?,local_port=?,remote_port=?,node_id=?,domain=? WHERE id=?`)
    .run(value.name, value.protocol, value.localHost, value.localPort, value.remotePort, value.nodeId, value.domain || null, req.params.id)
  if (!result.changes) return res.status(404).json({ message: '隧道不存在' })
  res.json((tunnelRows() as Array<{ id: string }>).find((item) => item.id === req.params.id))
})
app.patch('/api/tunnels/:id/status', (req, res) => {
  const { status } = z.object({ status: z.enum(['running', 'stopped']) }).parse(req.body)
  const result = db.prepare('UPDATE tunnels SET status=? WHERE id=?').run(status, req.params.id)
  if (!result.changes) return res.status(404).json({ message: '隧道不存在' })
  res.json({ id: req.params.id, status })
})
app.delete('/api/tunnels/:id', (req, res) => {
  const result = db.prepare('DELETE FROM tunnels WHERE id=?').run(req.params.id)
  if (!result.changes) return res.status(404).json({ message: '隧道不存在' })
  res.status(204).end()
})
app.get('/api/nodes', (_req, res) => res.json(db.prepare('SELECT * FROM nodes ORDER BY status, latency').all()))
app.get('/api/logs', (req, res) => {
  const tunnelId = typeof req.query.tunnelId === 'string' ? req.query.tunnelId : null
  const rows = tunnelId ? db.prepare('SELECT * FROM access_logs WHERE tunnel_id=? ORDER BY timestamp DESC LIMIT 100').all(tunnelId) : db.prepare('SELECT * FROM access_logs ORDER BY timestamp DESC LIMIT 100').all()
  res.json(rows)
})
app.get('/api/settings', (_req, res) => {
  const row = db.prepare("SELECT value FROM settings WHERE key='preferences'").get() as { value: string }
  res.json(JSON.parse(row.value))
})
app.put('/api/settings', (req, res) => {
  const value = z.object({ autoStart: z.boolean(), minimizeToTray: z.boolean(), notifications: z.boolean(), updateChannel: z.enum(['stable', 'beta']) }).parse(req.body)
  db.prepare("INSERT INTO settings (key,value) VALUES ('preferences',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(JSON.stringify(value))
  res.json(value)
})

const errorHandler: ErrorRequestHandler = (error, _req, res, _next) => {
  if (error instanceof z.ZodError) return res.status(400).json({ message: '请求参数无效', issues: error.issues })
  console.error(error)
  res.status(500).json({ message: '服务暂时不可用' })
}
app.use(errorHandler)
const relay = new WebSocketServer({ server: httpServer, path: '/relay' })
relay.on('connection', (socket, request) => {
  const query = new URL(request.url || '', `http://${request.headers.host}`).searchParams
  const tunnelId = query.get('tunnel'), token = query.get('token')
  const row = tunnelId ? db.prepare('SELECT id FROM tunnels WHERE id=? AND agent_token=?').get(tunnelId, token) : null
  if (!row || !tunnelId) return socket.close(1008, 'invalid token')
  agents.set(tunnelId, socket)
  db.prepare("UPDATE tunnels SET status='running' WHERE id=?").run(tunnelId)
  socket.on('message', (raw) => { try { const message = JSON.parse(raw.toString()); pending.get(message.id)?.(message); pending.delete(message.id) } catch {} })
  socket.on('close', () => { if (agents.get(tunnelId) === socket) agents.delete(tunnelId); db.prepare("UPDATE tunnels SET status='stopped' WHERE id=? AND status='running'").run(tunnelId) })
})
app.use('/public/:tunnelId', async (req, res, next) => {
  const socket = agents.get(req.params.tunnelId)
  if (!socket || socket.readyState !== WebSocket.OPEN) return res.status(503).json({ message: 'agent 未连接' })
  const id = randomUUID(), chunks: Buffer[] = []
  req.on('data', (chunk) => chunks.push(Buffer.from(chunk)))
  req.on('end', () => {
    pending.set(id, (message) => { res.status(message.status || 502); for (const [key, value] of Object.entries(message.headers || {})) if (typeof value === 'string') res.setHeader(key, value); res.end(Buffer.from(message.body || '', 'base64')) })
    socket.send(JSON.stringify({ id, method:req.method, path:req.originalUrl.replace(`/public/${req.params.tunnelId}`, '') || '/', headers:req.headers, body:Buffer.concat(chunks).toString('base64') }))
    setTimeout(() => { if (pending.delete(id)) res.status(504).json({ message: 'agent 响应超时' }) }, 30000)
  })
  req.on('error', next)
})
httpServer.listen(port, '127.0.0.1', () => console.log(`Nexious API listening on http://127.0.0.1:${port}`))
